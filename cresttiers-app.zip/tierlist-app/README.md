# CrestTiers — setup guide (no coding experience needed)

This is a real website with real accounts. You'll create two free accounts
(Supabase for the database/logins, Vercel for hosting), and you won't touch
a terminal at all.

## 1. Create the database (Supabase)

1. Go to https://supabase.com → **Start your project** → sign up (free).
2. Click **New project**. Pick any name, set a database password (save it
   somewhere), pick a region near you, click **Create new project**. Wait
   ~2 minutes while it spins up.
3. In the left sidebar, click **SQL Editor** → **New query**.
4. Open the file `supabase/schema.sql` from this folder, copy *all* of it,
   paste it into the editor, and click **Run**. This creates the tables.
5. In the left sidebar, click **Authentication** → **Providers** → **Email**.
   Turn **off** "Confirm email" (this just means people can log in right
   after signing up, without clicking a confirmation email — simpler for a
   small community board; leave it on if you'd rather require confirmation).
6. In the left sidebar, click **Settings** → **API**. Keep this tab open —
   you'll need three values from it in step 3 below:
   - **Project URL**
   - **anon public** key
   - **service_role** key (click "Reveal" — keep this one secret, never share it)

## 2. Put the code on GitHub

1. Go to https://github.com → sign up (free) if you don't have an account.
2. Click the **+** in the top right → **New repository**. Name it
   `cresttiers`, keep it Private or Public (your choice), click **Create repository**.
3. On the new repo page, click **uploading an existing file**.
4. Open this project folder on your computer, select *all* files and
   folders inside it, and drag them into the GitHub upload box. Click
   **Commit changes**.

## 3. Deploy it (Vercel)

1. Go to https://vercel.com → sign up with your GitHub account (free).
2. Click **Add New...** → **Project**, and import the `cresttiers` repo
   you just created.
3. Before clicking Deploy, open **Environment Variables** and add these
   four (values from Supabase step 6, plus one you make up):

   | Name | Value |
   |---|---|
   | `NEXT_PUBLIC_SUPABASE_URL` | the Project URL from Supabase |
   | `NEXT_PUBLIC_SUPABASE_ANON_KEY` | the anon public key from Supabase |
   | `SUPABASE_SERVICE_ROLE_KEY` | the service_role key from Supabase |
   | `ADMIN_INVITE_CODE` | any secret phrase you make up, e.g. `sword-badger-77` |

4. Click **Deploy**. After ~1-2 minutes you'll get a live URL like
   `cresttiers.vercel.app` — that's your real website.

## 4. Become the first admin

1. Visit your live site, click **Sign up**, create your account.
2. Click **Admin panel** (top right), then enter the `ADMIN_INVITE_CODE`
   you picked in step 3. You're now an admin.
3. From the admin panel you can add players, set their tier in each
   category, and promote other people to admin by their username — no
   code needed for that part, that's only for the first admin.

## Notes

- Never share your `service_role` key or `ADMIN_INVITE_CODE` publicly — the
  invite code is only meant to be handed out privately to people you trust
  with admin access.
- Any time you push new changes to the GitHub repo, Vercel redeploys
  automatically.
- If you ever want to change the invite code, update the
  `ADMIN_INVITE_CODE` environment variable in Vercel and redeploy.
